"""Edge Gateway Hub"""
